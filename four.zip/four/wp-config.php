<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'four' );

/** MySQL database username */
define( 'DB_USER', 'bidyut' );

/** MySQL database password */
define( 'DB_PASSWORD', '123' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '0F4eao53px,0KvrA+|gAas+~+SGBRjrR;Clbmobu1f~p6k)xtM.BUapVLvO>UJd.' );
define( 'SECURE_AUTH_KEY',  ',tLr*yB07Pa?ev$!8V(xzIj~fcXe06m9G(;f/TO<!r($DyO0JG&O<,IC#Z7z>6MA' );
define( 'LOGGED_IN_KEY',    '2%5_5Qo,8.h%[~WkzFBQN?GFbn_ivTo$`_4$<%=wwdD/B7Xyg*ls0`nFh8b6mgcJ' );
define( 'NONCE_KEY',        '+TeznpBjj`+ye!C#ykK%.lZOhk@=E$3j(Y}JuZaJ<L,GB$JDG^B*6n$Iyw4c:Y!W' );
define( 'AUTH_SALT',        'b`5%tIizt#l0H#tMU#lvrz}u;JPJHm3 b`XCQCKm$_6_R)>^bXGi&cLg+(f)?CtR' );
define( 'SECURE_AUTH_SALT', 'f&NZG2bcy8-4o.46!HO=%NA<g#9./l+5m:1v:}^.&Pp{AE5o>|)0~*=,Uf]-yNYT' );
define( 'LOGGED_IN_SALT',   'Pcn|yQpc@#.l1P6,9!-$?}g;*l.h:Wn8by<AFlLj#_2z8TYjF|,sWGkEB^xN?5sw' );
define( 'NONCE_SALT',       ')tLHY//q$03Nky7bJVPcJ+IJsFC%Q01p4F0[db M5Cvv.7}z#EWGe(Da!/_{o;,7' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
